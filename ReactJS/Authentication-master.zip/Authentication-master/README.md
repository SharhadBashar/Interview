This is a simple project that allows a users to sign up to a site with an email and password 
The user model is saved and stored in mongo db.
Once the user is signed up, they are redirected to the restricted page
If a user already exists, they can sign in to visit the page
Created with Node, MongoDB, React and Redux


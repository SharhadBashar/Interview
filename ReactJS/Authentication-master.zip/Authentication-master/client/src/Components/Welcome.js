import React from 'react';

export default () => {
    return (
        <h3>Welcome to the App</h3>
    );
};